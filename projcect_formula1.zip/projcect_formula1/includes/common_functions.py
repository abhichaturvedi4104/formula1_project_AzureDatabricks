# Databricks notebook source
from pyspark.sql.functions import current_timestamp
def ingest_date(input_df):
    output_df=input_df.withColumn("ingestion_date",current_timestamp())
    return output_df

# COMMAND ----------

def incremental_load(input_df,partition_fld,database,table_name):
    spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    output_list=[]
    for col in input_df.schema.names:
        if col != partition_fld:
            output_list.append(col)
    output_list.append(partition_fld)
    output_df=input_df.select(output_list)
    if spark._jsparkSession.catalog().tableExists(f'{database}.{table_name}'):
        output_df.write.mode('overwrite').insertInto(f'{database}.{table_name}')
    else:
        output_df.write.mode('overwrite').partitionBy(partition_fld).format('parquet').saveAsTable(f'{database}.{table_name}')
   # return output_df

# COMMAND ----------

def merge_delta_data(input_df,db,table,folder_path,merge_condition,partition_col):
    
    spark.conf.set("spark.databricks.optimizer.dynamicPartitionPruning","true")
    from delta.tables import DeltaTable
    if (spark._jsparkSession.catalog().tableExists(f"{db}.{table}")):
        deltaTable=DeltaTable.forPath(spark, f"{folder_path}/{table}")
        deltaTable.alias('tgt').merge(input_df.alias('src'),merge_condition)\
  .whenMatchedUpdateAll()\
  .whenNotMatchedInsertAll()\
  .execute()
    else:
        input_df.write.mode("overwrite").partitionBy(partition_col).format("delta").saveAsTable(f"{db}.{table}")

# COMMAND ----------

