# Databricks notebook source
raw_folder_path="/mnt/formula1adlss/raw/"

# COMMAND ----------

processed_folder_path="/mnt/formula1adlss/processed/"

# COMMAND ----------

presentation_folder_path="/mnt/formula1adlss/presentation/"

# COMMAND ----------

