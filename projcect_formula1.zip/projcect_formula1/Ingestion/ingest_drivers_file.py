# Databricks notebook source
# MAGIC %md
# MAGIC ###ingest drivers file

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step - 1 read json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StringType,DateType,StructType,StructField,DoubleType,IntegerType

# COMMAND ----------

name_schema=StructType(fields=[StructField("forename",StringType(),True),\
                                 StructField("surname",StringType(),True)])

# COMMAND ----------

drivers_schema=StructType(fields=[StructField("driverId",IntegerType(),False),\
                                 StructField("driverRef",StringType(),True),\
                                 StructField("number",IntegerType(),True),\
                                 StructField("code",StringType(),False),\
                                 StructField("name",name_schema),\
                                 StructField("dob",DateType(),True),\
                                 StructField("nationality",StringType(),True),\
                                 StructField("url",StringType(),True)])

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

drivers_df=spark.read.\
schema(drivers_schema).\
json(f'{raw_folder_path}/{file_date}/drivers.json')

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

drivers_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step - 2 Rename cols and add ingestion date

# COMMAND ----------

from pyspark.sql.functions import col,current_timestamp,lit,concat

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------



# COMMAND ----------

drivers_renamed_df=drivers_df.withColumnRenamed("driverId","driver_id").\
withColumnRenamed("driverRef","driver_ref").\
withColumn("ingestion_date",current_timestamp()).\
withColumn("name",concat(col("name.forename"), lit(" "),col("name.surname"))).\
          withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))

# COMMAND ----------

display(drivers_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step 3 Drop extra columns

# COMMAND ----------

drivers_final_df=drivers_renamed_df.drop(col("url"))

# COMMAND ----------

display(drivers_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 5 write to parquet

# COMMAND ----------

drivers_final_df.write.mode("overwrite").format("delta").saveAsTable('processed.drivers')

# COMMAND ----------

#display(spark.read.parquet('/mnt/formula1adlss/processed/drivers/'))

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.drivers

# COMMAND ----------

dbutils.notebook.exit("success")