# Databricks notebook source
# MAGIC %md
# MAGIC ###Ingest laptimes folder 

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step - 2 Read csv file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,FloatType

# COMMAND ----------

lap_schema=StructType(fields=[StructField("raceId",IntegerType(),False),\
                                StructField("driverId",IntegerType(),True),\
                         StructField("lap",IntegerType(),True),\
                                                       StructField("position",IntegerType(),True),\
                         StructField("time",StringType(),True),\
                                 StructField("milliseconds",IntegerType(),True),\
                         ])

# COMMAND ----------

lap_df=spark.read.schema(lap_schema).csv(f'{raw_folder_path}/{file_date}/lap_times')

# COMMAND ----------

display(lap_df)

# COMMAND ----------

lap_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 2 Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------

lap_final_df=lap_df.withColumnRenamed("raceId","race_id").\
withColumnRenamed("driverId","driver_id").\
withColumn("ingestion_date",current_timestamp()).\
withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))

# COMMAND ----------

display(lap_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 3 Write to parquet

# COMMAND ----------

#lap_final_df.write.mode("overwrite").format("parquet").saveAsTable('processed.lap_times')

# COMMAND ----------

#incremental_load(lap_final_df,'race_id','processed','lap_times')

# COMMAND ----------

merge_condition="tgt.driver_id=src.driver_id and tgt.race_id=src.race_id and tgt.lap=src.lap"
merge_delta_data(lap_final_df,'processed','lap_times',processed_folder_path,merge_condition,'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.lap_times

# COMMAND ----------

##display(spark.read.parquet(f'{processed_folder_path}/lap_times/'))

# COMMAND ----------

dbutils.notebook.exit("success")

# COMMAND ----------

