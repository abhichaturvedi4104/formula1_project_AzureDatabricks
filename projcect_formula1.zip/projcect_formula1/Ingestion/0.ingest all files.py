# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------



# COMMAND ----------

dbutils.notebook.run('ingest_circuits_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_results_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_cunstructors_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_drivers_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_pitstop_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_lap_times',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_races_file',0,{"p_source": "Ergast API","file_date": "2021-04-18"})

# COMMAND ----------

dbutils.notebook.run('ingest_qualifying_folder',0,{"p_source": "Ergast API","file_date": "2021-04-18"})