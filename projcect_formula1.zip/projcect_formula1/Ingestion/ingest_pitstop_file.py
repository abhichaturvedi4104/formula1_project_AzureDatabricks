# Databricks notebook source
# MAGIC %md
# MAGIC ###Ingest Pitstop file (multiline json file)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step - 2 Read json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,FloatType

# COMMAND ----------

pitshop_schema=StructType(fields=[StructField("raceId",IntegerType(),False),\
                                StructField("driverId",IntegerType(),True),\
                         StructField("stop",StringType(),True),\
                         StructField("lap",IntegerType(),True),\
                         StructField("time",StringType(),True),\
                         StructField("duration",StringType(),True),\
                                 StructField("milliseconds",IntegerType(),True),\
                         ])

# COMMAND ----------

pitshop_df=spark.read.schema(pitshop_schema).option("multiline",True).json(f'{raw_folder_path}/{file_date}/pit_stops.json')

# COMMAND ----------

display(pitshop_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 2 Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------

pitStop_final_df=pitshop_df.withColumnRenamed("raceId","race_id").\
withColumnRenamed("driverId","driver_id").\
withColumn("ingestion_date",current_timestamp()).\
withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))

# COMMAND ----------

display(pitStop_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 3 Write to parquet

# COMMAND ----------

#pitStop_final_df.write.mode("overwrite").format("parquet").saveAsTable('processed.pit_stop')

# COMMAND ----------

#incremental_load(pitStop_final_df,'race_id','processed','pit_stop')

# COMMAND ----------

#display(spark.read.parquet(f'{processed_folder_path}/pit_stop/'))

# COMMAND ----------

merge_condition="tgt.driver_id=src.driver_id and tgt.race_id=src.race_id and tgt.stop=src.stop"
merge_delta_data(pitStop_final_df,'processed','pit_stop',processed_folder_path,merge_condition,'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.pit_stop

# COMMAND ----------

dbutils.notebook.exit("success")

# COMMAND ----------

