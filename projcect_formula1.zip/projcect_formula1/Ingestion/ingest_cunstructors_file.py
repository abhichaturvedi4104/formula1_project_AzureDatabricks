# Databricks notebook source
# MAGIC %md
# MAGIC ###Ingest constructors file

# COMMAND ----------

constructors_schema="constructorId INT,constructorRef String,name String,nationality String,url String"

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

constructor_df=spark.read.\
schema(constructors_schema).\
json(f'{raw_folder_path}/{file_date}/constructors.json')

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

constructor_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 2 Drop unwanted coloumns

# COMMAND ----------

constructor_drop_df=constructor_df.drop('url')

# COMMAND ----------

display(constructor_drop_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 3 Rename Columns and add ingestion date

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------

constructor_final_df=constructor_drop_df.withColumnRenamed("constructorId","constructor_id").\
withColumnRenamed("constructorRef","constructor_ref").\
withColumn("ingestion_date",current_timestamp()).\
          withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))


# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 4 write to parquet

# COMMAND ----------

constructor_final_df.write.mode("overwrite").format("delta").saveAsTable('processed.constructors')

# COMMAND ----------

#display(spark.read.parquet(f'{processed_folder_path}/constructors'))

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.constructors

# COMMAND ----------

dbutils.notebook.exit("success")