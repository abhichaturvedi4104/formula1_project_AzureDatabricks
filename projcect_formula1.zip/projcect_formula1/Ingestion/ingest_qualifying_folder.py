# Databricks notebook source
# MAGIC %md
# MAGIC ###Ingest qualifying folder (multiline json file)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step - 2 Read json file

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,FloatType

# COMMAND ----------

qualifying_schema=StructType(fields=[StructField("qualifyId",IntegerType(),False),\
                                  StructField("raceId",IntegerType(),True),\
                                StructField("driverId",IntegerType(),True),\
                                  StructField("constructorId",IntegerType(),True),\
                         StructField("number",IntegerType(),True),\
                         StructField("position",IntegerType(),True),\
                         StructField("q1",StringType(),True),\
                         StructField("q2",StringType(),True),\
                                 StructField("q3",StringType(),True),\
                         ])

# COMMAND ----------

qualify_df=spark.read.schema(qualifying_schema).option("multiline",True).json(f'{raw_folder_path}/{file_date}/qualifying')

# COMMAND ----------

display(qualify_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 2 Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------

qualify_final_df=qualify_df.withColumnRenamed("qualifyId","qualifying_id").\
withColumnRenamed("raceId","race_id").\
withColumnRenamed("driverId","driver_id").\
withColumnRenamed("constructorId","constructor_id").\
withColumn("ingestion_date",current_timestamp()).\
withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))

# COMMAND ----------

display(qualify_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 3 Write to parquet

# COMMAND ----------

##qualify_final_df.write.mode("overwrite").format("parquet").saveAsTable('processed.qualifying')

# COMMAND ----------

#incremental_load(qualify_final_df,'race_id','processed','qualifying')

# COMMAND ----------

#display(spark.read.parquet(f'{processed_folder_path}/qualifying/'))

# COMMAND ----------

merge_condition="tgt.qualifying_id=src.qualifying_id"
merge_delta_data(qualify_final_df,'processed','qualifying',processed_folder_path,merge_condition,'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.qualifying

# COMMAND ----------

dbutils.notebook.exit("success")