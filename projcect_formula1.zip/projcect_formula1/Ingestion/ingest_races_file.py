# Databricks notebook source
# MAGIC %md
# MAGIC ###Ingest Races File

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step 1 - Create Schema and read the csv

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,DoubleType,DateType

# COMMAND ----------

races_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                                StructField("year",IntegerType(),True),
                                StructField("round",IntegerType(),True),
                                StructField("circuitId",IntegerType(),True),
                                StructField("name",StringType(),True),
                                StructField("date",DateType(),True),
                                StructField("time",StringType(),True),
                                StructField("url",StringType(),True)])


# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

races_df=spark.read.option("header", True).\
schema(races_schema)\
.csv(f'{raw_folder_path}/{file_date}/races.csv')

# COMMAND ----------

display(races_df)

# COMMAND ----------

races_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### step -2 select specific columns

# COMMAND ----------

from pyspark.sql.functions import col,lit,to_timestamp,concat,current_timestamp

# COMMAND ----------

races_selected_df=races_df.select(col("raceId"),col("year"),col("round"),col("circuitId"),col("name"),col("date"),col("time"))

# COMMAND ----------

display(races_selected_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####step - 3 rename columns and tranform

# COMMAND ----------

dbutils.widgets.text("p_source","")
v_data_source=dbutils.widgets.get("p_source")

# COMMAND ----------

races_renamed_df=races_selected_df.withColumnRenamed("raceId","race_id").\
withColumnRenamed("year","race_year").\
withColumnRenamed("circuitId","circuit_id").\
withColumn("race_timestamp",to_timestamp(concat(col("date"),lit(' '),col("time")),'yyyy-MM-dd hh:mm:ss')).\
withColumn("data_source",lit(v_data_source)).\
withColumn("file_date",lit(file_date))

# COMMAND ----------

display(races_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####step - 4 Ingestion details and remove extra cols

# COMMAND ----------

races_tansform_df=races_renamed_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

display(races_tansform_df)

# COMMAND ----------

races_transformed_df=races_tansform_df.select(col("race_id"),\
                                              col("race_year"),col("round"),\
                                              col("circuit_id"),col("name"),\
                                              col("race_timestamp"),col("ingestion_date"),col("file_date"))

# COMMAND ----------

display(races_transformed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step - 5 dataframe to parquet

# COMMAND ----------

races_transformed_df.write.mode("overwrite").format("delta").saveAsTable('processed.races')

# COMMAND ----------

#display(spark.read.parquet(f'{processed_folder_path}/races/'))

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from processed.races

# COMMAND ----------

dbutils.notebook.exit("success")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table processed.races

# COMMAND ----------

