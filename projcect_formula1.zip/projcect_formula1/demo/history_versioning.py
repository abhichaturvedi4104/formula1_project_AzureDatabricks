# Databricks notebook source
# MAGIC %md
# MAGIC ######1.History and versioning
# MAGIC ######2.Time travel
# MAGIC ######3.Vaccum

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC history delta_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta_demo.drivers_merge VERSION AS OF 2

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta_demo.drivers_merge TIMESTAMP AS OF 
# MAGIC "2022-12-26T12:02:29.000+0000"

# COMMAND ----------

df=spark.read.format("delta").option("timestampAsof","2022-12-26T12:02:29.000+0000").load("/mnt/formula1adlss/demo/drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM delta_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta_demo.drivers_merge TIMESTAMP AS OF "2022-12-26T12:02:29.000+0000"

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.retentionDurationCheck.enabled =false;
# MAGIC VACUUM delta_demo.drivers_merge RETAIN 0 HOURS

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta_demo.drivers_merge TIMESTAMP AS OF "2022-12-26T12:02:29.000+0000"

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM delta_demo.drivers_merge WHERE driverId =1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO delta_demo.drivers_merge tgt
# MAGIC USING delta_demo.drivers_merge VERSION AS OF 3 src
# MAGIC ON (tgt.driverId=src.driverId)
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT *

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.drivers_merge

# COMMAND ----------

