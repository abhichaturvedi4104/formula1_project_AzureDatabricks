# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS delta_demo.drivers_txn(
# MAGIC driverId Int,
# MAGIC dob DATE,
# MAGIC forename String,
# MAGIC surname String,
# MAGIC createdDate Date,
# MAGIC updatedDate Date
# MAGIC )
# MAGIC Using Delta

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY delta_demo.drivers_txn

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO delta_demo.drivers_txn
# MAGIC SELECT * FROM delta_demo.drivers_merge where driverId=1

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY delta_demo.drivers_txn

# COMMAND ----------

