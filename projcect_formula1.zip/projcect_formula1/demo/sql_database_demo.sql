-- Databricks notebook source
-- MAGIC %md 
-- MAGIC #####Sql database demo
-- MAGIC ######1.create database
-- MAGIC ######2.Use,show,current_database commands

-- COMMAND ----------

Create database if not exists demo;

-- COMMAND ----------

show databases


-- COMMAND ----------

describe database extended demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

use demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Managed table demo
-- MAGIC ######1.create table using python,sql
-- MAGIC ######2.drop managed table
-- MAGIC ######3.describe table

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df=spark.read.parquet(f'{presentation_folder_path}/race_results')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo_race_res_python")

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables

-- COMMAND ----------

describe extended demo_race_res_python

-- COMMAND ----------

select * from demo_race_res_python
where race_year='2020'

-- COMMAND ----------

create table demo_race_res_sql
as
select * from demo_race_res_python
where race_year='2020'

-- COMMAND ----------

desc extended demo_race_res_sql

-- COMMAND ----------

show tables

-- COMMAND ----------

drop table demo_race_res_sql

-- COMMAND ----------

show tables

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######External table demo
-- MAGIC ######1.create table using python
-- MAGIC ######2.create table using sql
-- MAGIC ######3.effects of dropping external table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path",f'{presentation_folder_path}/race_results_ext_python').saveAsTable("ext_race_Res_python")

-- COMMAND ----------

describe extended ext_race_Res_python

-- COMMAND ----------

create table ext_race_Res_sql
(race_year int,
race_name string,
race_date timestamp,
circuits_location string,
driver_name string,
driver_number int,
driver_nationality string,
team string,
position int,
grid int,
fastest_lap int,
race_time string,
points float,
created_date timestamp
)
using parquet
location '/mnt/formula1adlss/presentation/ext_race_Res_sql'

-- COMMAND ----------

describe extended ext_race_res_sql

-- COMMAND ----------

insert into ext_race_Res_sql
(select * from ext_race_Res_python where race_year='2020')

-- COMMAND ----------

select count(*) from ext_race_Res_sql where race_year='2020'

-- COMMAND ----------

drop table ext_race_Res_sql

-- COMMAND ----------

show tables

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Views create tables
-- MAGIC ######1.create temp view
-- MAGIC ######2.create global temp view
-- MAGIC ######3.create permanent view

-- COMMAND ----------

create or replace temp view lc_temp_view as
select * from demo_race_res_python
where race_year='2018'

-- COMMAND ----------

create or replace global temp view gb_temp_view as
select * from demo_race_res_python
where race_year='2019'

-- COMMAND ----------

show tables in global_temp


-- COMMAND ----------

select * from global_temp.gb_temp_view

-- COMMAND ----------

create or replace view pv_temp_view as
select * from demo_race_res_python
where race_year='2017'

-- COMMAND ----------

show tables

-- COMMAND ----------

select * from 
pv_temp_view

-- COMMAND ----------

