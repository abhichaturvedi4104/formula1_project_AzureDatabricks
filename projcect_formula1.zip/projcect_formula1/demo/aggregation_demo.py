# Databricks notebook source
# MAGIC %md
# MAGIC ####Aggregation Functions Demo

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

demo_df=race_results_df.filter("race_year=2020")

# COMMAND ----------

display(demo_df)

# COMMAND ----------

from pyspark.sql.functions import sum,countDistinct,count,col

# COMMAND ----------

demo_df.select(countDistinct("race_name")).show()

# COMMAND ----------

demo_df.select(sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name='Lewis Hamilton'").select(sum("points"),countDistinct("race_name")).\
withColumnRenamed("sum(points)","total_points").\
withColumnRenamed("count(DISTINCT race_name)","total_races").\
show()

# COMMAND ----------

demo_grp_df=demo_df.groupBy("driver_name").agg(sum("points").alias("total_points"),countDistinct("race_name").alias("total_races")).orderBy("total_points" ,ascending=False)

# COMMAND ----------

display(demo_grp_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####window functions

# COMMAND ----------

demo_wind_df=race_results_df.filter("race_year in (2019,2020)").groupBy("race_year","driver_name").agg(sum("points").alias("total_points"),countDistinct("race_name").alias("total_races"))
display(demo_wind_df)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc,rank

driverrank=Window.partitionBy("race_year").orderBy(desc("total_points"))
demo_wind_df.withColumn("rank",rank().over(driverrank)).show()

# COMMAND ----------

