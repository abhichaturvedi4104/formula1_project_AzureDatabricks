# Databricks notebook source
# MAGIC %md
# MAGIC ####Join demo

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df=spark.read.parquet(f'{processed_folder_path}/races').withColumnRenamed("name","races_name").filter("race_year=2019")

# COMMAND ----------

circuits_df=spark.read.parquet(f'{processed_folder_path}/circuits').withColumnRenamed("name","circuits_name").filter("circuit_id<69")

# COMMAND ----------

# MAGIC %md
# MAGIC #####inner join

# COMMAND ----------

races_circuits_df=circuits_df.join(races_df,races_df.circuit_id==circuits_df.circuit_id,"inner").\
select(circuits_df.circuits_name,circuits_df.location,circuits_df.race_country,races_df.races_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####left join

# COMMAND ----------

races_circuits_df=circuits_df.join(races_df,races_df.circuit_id==circuits_df.circuit_id,"left").\
select(circuits_df.circuits_name,circuits_df.location,circuits_df.race_country,races_df.races_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####right join

# COMMAND ----------

races_circuits_df=circuits_df.join(races_df,races_df.circuit_id==circuits_df.circuit_id,"right").\
select(circuits_df.circuits_name,circuits_df.location,circuits_df.race_country,races_df.races_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####full outer join

# COMMAND ----------

races_circuits_df=circuits_df.join(races_df,races_df.circuit_id==circuits_df.circuit_id,"full").\
select(circuits_df.circuits_name,circuits_df.location,circuits_df.race_country,races_df.races_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####cross join

# COMMAND ----------

races_circuits_df=circuits_df.crossJoin(races_df)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

races_circuits_df.count()

# COMMAND ----------

