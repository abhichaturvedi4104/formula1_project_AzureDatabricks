# Databricks notebook source
# MAGIC %md
# MAGIC ######1.Write data to delta lake managed table
# MAGIC ######2.Write data to delta lake external table
# MAGIC ######3.Read data from a delta lake file
# MAGIC ######4.Read data from delta lake table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS delta_demo
# MAGIC location '/mnt/formula1adlss/demo'

# COMMAND ----------

results_df=spark.read.option('inferSchema', True).json('/mnt/formula1adlss/raw/2021-03-28/results.json')

# COMMAND ----------

display(results_df)

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").saveAsTable("delta_demo.results_managed")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.results_managed

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").save("/mnt/formula1adlss/demo/results_external")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS delta_demo.results_external
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/formula1adlss/demo/results_external"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.results_external

# COMMAND ----------

results_ext_df=spark.read.format("delta").load("/mnt/formula1adlss/demo/results_external")

# COMMAND ----------

display(results_ext_df)

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").partitionBy("constructorId").saveAsTable("delta_demo.results_partioned")

# COMMAND ----------

