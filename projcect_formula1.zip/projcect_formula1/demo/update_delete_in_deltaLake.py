# Databricks notebook source
# MAGIC %md
# MAGIC #####1.Update delta table
# MAGIC #####2.Delete from delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE delta_demo.results_managed
# MAGIC SET points = 11 - position
# MAGIC WHERE position <= 10

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.results_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_demo.results_managed

# COMMAND ----------

from delta.tables import *

deltaTable = DeltaTable.forPath(spark,"/mnt/formula1adlss/demo/results_managed")
deltaTable.update("position <= 10", {"points": "21- position"})

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC DELETE FROM delta_demo.results_managed where position > 10;

# COMMAND ----------

deltaTable = DeltaTable.forPath(spark,"/mnt/formula1adlss/demo/results_managed")
deltaTable.delete("points = 0")

# COMMAND ----------

