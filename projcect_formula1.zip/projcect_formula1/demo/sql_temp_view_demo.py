# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df=spark.read.parquet(f'{presentation_folder_path}/race_results')

# COMMAND ----------

race_results_df.createOrReplaceTempView("race_result_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from race_result_view  where team='Kuzma'

# COMMAND ----------

sql_df=spark.sql("select * from race_result_view")

# COMMAND ----------

# MAGIC %md
# MAGIC #####Global temp view

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results

# COMMAND ----------

