# Databricks notebook source
# MAGIC %md
# MAGIC ####Filter demo

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

demo_df=spark.read.parquet(f'{processed_folder_path}/races')

# COMMAND ----------

demo_filter_df=demo_df.where(demo_df.race_year==2019)

# COMMAND ----------

display(demo_filter_df)

# COMMAND ----------

