# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS delta_demo.drivers_parquetToDelta(
# MAGIC driverId Int,
# MAGIC dob DATE,
# MAGIC forename String,
# MAGIC surname String,
# MAGIC createdDate Date,
# MAGIC updatedDate Date
# MAGIC )
# MAGIC using parquet

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO delta_demo.drivers_parquetToDelta
# MAGIC SELECT * FROM delta_demo.drivers_merge 

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA delta_demo.drivers_parquetToDelta

# COMMAND ----------

df=spark.table("delta_demo.drivers_parquetToDelta")

# COMMAND ----------

df.write.format('parquet').save("/mnt/formula1adlss/demo/drivers_parquetToDelta_new")

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA parquet.`/mnt/formula1adlss/demo/drivers_parquetToDelta_new`

# COMMAND ----------

