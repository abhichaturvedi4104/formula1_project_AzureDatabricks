-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS processed
LOCATION "/mnt/formula1adlss/processed/"

-- COMMAND ----------

DESCRIBE DATABASE raw

-- COMMAND ----------

DESCRIBE DATABASE processed

-- COMMAND ----------

