-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS raw;

-- COMMAND ----------

use raw

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS races( raceId int,
                                  year  int,
                                  round int,
                                 circuitId int,
                                  name String,
                               date date,
                                  time String,
                                 url String)
                                   USING csv
                                   OPTIONS(PATH '/mnt/formula1adlss/raw/races.csv',HEADER True)


-- COMMAND ----------

select * from races

-- COMMAND ----------

