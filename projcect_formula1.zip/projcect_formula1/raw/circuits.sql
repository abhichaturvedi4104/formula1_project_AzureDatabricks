-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS raw;

-- COMMAND ----------

use raw

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS circuits( circuitId int,
                                  circuitRef  String,
                                  name String,
                                 location String,
                                  country String,
                               lat Double,
                                  lng Double,
                                  alt Int,
                                 url String)
                                   USING csv
                                   OPTIONS(PATH '/mnt/formula1adlss/raw/circuits.csv',HEADER True)


-- COMMAND ----------

select * from circuits 

-- COMMAND ----------

