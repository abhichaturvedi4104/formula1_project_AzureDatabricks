-- Databricks notebook source
use raw

-- COMMAND ----------

-- MAGIC %md 
-- MAGIC ######Lap Time Folder - create sql table using  multiple files from a folder

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS lap_times(raceId INT,driverId INT,lap Int,position Int,time String,milliseconds Int)
USING csv
OPTIONS(path '/mnt/formula1adlss/raw/lap_times/')

-- COMMAND ----------

SELECT * FROM lap_times

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Qualifying folder - Create sql table using multiple multiline json source files from a folder

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS qualify(qualifyId INT,raceId INT,driverId INT,constructorId INT,number INT,
position INT,q1 String,q2 String,q3 String)
USING json
OPTIONS(path '/mnt/formula1adlss/raw/qualifying/',multiline True)

-- COMMAND ----------

SELECT * FROM qualify

-- COMMAND ----------

