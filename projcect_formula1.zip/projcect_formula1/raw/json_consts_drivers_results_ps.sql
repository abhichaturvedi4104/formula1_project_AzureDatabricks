-- Databricks notebook source
-- MAGIC %md
-- MAGIC ######Create Database

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS raw;

-- COMMAND ----------

use raw

-- COMMAND ----------

-- MAGIC %md ######Create constructors table using single line json file

-- COMMAND ----------



-- COMMAND ----------

CREATE TABLE IF NOT EXISTS constructors( constructorId INT,constructorRef String,name String,nationality String,url String)
                                   USING json
                                   OPTIONS(PATH '/mnt/formula1adlss/raw/constructors.json')


-- COMMAND ----------

select * from constructors

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Create driver table using struct(unique schema scenario)

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS drivers(driverId INT,driverRef String,number INT,code String,name STRUCT<forename String,surname String>,dob date,nationality String,url String
)
USING json
OPTIONS(path '/mnt/formula1adlss/raw/drivers.json')

-- COMMAND ----------

select * from drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Create table results

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS results(resultId INT,raceId INT,driverId INT,constructorId INT,number INT,grid INT,
position INT,positionText String,positionOrder INT,points float,laps Int,time String,milliseconds Int,fastestLap Int,
rank Int,fastestLapTime Int,fastestLapSpeed float,statusId String)

USING json 
OPTIONS (path '/mnt/formula1adlss/raw/results.json')

-- COMMAND ----------

SELECT * FROM results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######Create table Pit_stops from multiline source json file

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS pit_stop(raceId INT,driverId INT,stop String,lap Int,time String,duration String,milliseconds Int)
USING json
OPTIONS(PATH '/mnt/formula1adlss/raw/pit_stops.json',multiline True)

-- COMMAND ----------

SELECT * FROM pit_stop

-- COMMAND ----------

