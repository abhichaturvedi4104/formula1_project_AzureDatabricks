# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

# MAGIC %md ######Find year for which data has to be processed

# COMMAND ----------

race_res_list=spark.read.format("delta").load(f'{presentation_folder_path}/race_results').filter(f"file_date='{file_date}'").\
select('race_year').distinct().collect()
##display(race_res_df)

# COMMAND ----------

race_yr_list=[]
for yr in race_res_list:
    race_yr_list.append(yr.race_year)
print(race_yr_list)

# COMMAND ----------

from pyspark.sql.functions import sum,when,col,count,rank,desc

# COMMAND ----------

race_res_df=spark.read.format("delta").load(f'{presentation_folder_path}/race_results').\
filter(col('race_year').isin(race_yr_list))
display(race_res_df)

# COMMAND ----------

driver_rank_df=race_res_df.\
groupBy("race_year","driver_name","driver_nationality").\
agg((sum("points")).alias("total_points"),count(when(col("position")==1,True)).alias("wins"))
display(driver_rank_df)

# COMMAND ----------

from pyspark.sql.window import Window

driver_rank=Window.orderBy(desc("total_points"),desc("wins"))
driver_final_df=driver_rank_df.withColumn("rank",rank().over(driver_rank))

# COMMAND ----------

##driver_final_df.write.mode("overwrite").format("parquet").saveAsTable('presentation.drivers_standing')

# COMMAND ----------

#incremental_load(driver_final_df,'race_year','presentation','driver_standings')

# COMMAND ----------

merge_condition="tgt.driver_name=src.driver_name and tgt.race_year=src.race_year"
merge_delta_data(driver_final_df,'presentation','driver_standings',presentation_folder_path,merge_condition,'race_year')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from presentation.driver_standings

# COMMAND ----------

