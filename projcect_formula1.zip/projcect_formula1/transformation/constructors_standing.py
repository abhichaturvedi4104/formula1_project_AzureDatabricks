# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

const_list=spark.read.format("delta").load(f'{presentation_folder_path}/race_results').filter(f"file_date='{file_date}'").select('race_year').distinct().collect()

# COMMAND ----------

yr_list=[]
for yr in const_list:
    yr_list.append(yr.race_year)
print(yr_list)

# COMMAND ----------

from pyspark.sql.functions import sum,count,when,col,desc,rank

# COMMAND ----------

const_df=spark.read.format("delta").load(f'{presentation_folder_path}/race_results').filter(col('race_year'). isin(yr_list))
display(const_df)

# COMMAND ----------

const_standing_df=const_df.\
groupBy("race_year","team").\
agg(sum("points").alias("total_points"),\
count(when(col("position")==1,True)).alias("wins"))

# COMMAND ----------

from pyspark.sql.window import Window
const_rank=Window.orderBy(desc("total_points"),desc("wins"))
cons_rank_df=const_standing_df.withColumn("rank",rank().over(const_rank))
display(cons_rank_df)

# COMMAND ----------

#incremental_load(cons_rank_df,'race_year','presentation','constructors_standing')

# COMMAND ----------

#display(spark.read.parquet(f'{presentation_folder_path}/constructors_standing'))

# COMMAND ----------

merge_condition="tgt.team=src.team and tgt.race_year=src.race_year"
merge_delta_data(cons_rank_df,'presentation','constructor_standings',presentation_folder_path,merge_condition,'race_year')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from presentation.constructor_standings