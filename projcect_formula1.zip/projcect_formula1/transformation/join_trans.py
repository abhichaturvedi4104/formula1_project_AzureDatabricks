# Databricks notebook source
# MAGIC %md
# MAGIC #####Join transformation for presentation layer

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text("file_date","2021-03-21")
file_date=dbutils.widgets.get("file_date")

# COMMAND ----------

from pyspark.sql.functions import date_format,current_timestamp,lit

# COMMAND ----------

races_df=spark.read.format("delta").load(f'{processed_folder_path}/races').\
withColumnRenamed("name","race_name").\
withColumnRenamed("race_timestamp","race_date").\
withColumn("file_date",lit(file_date))
display(races_df)

# COMMAND ----------

results_df=spark.read.format("delta").load(f'{processed_folder_path}/results').\
filter(f"file_date='{file_date}'").\
withColumnRenamed("time","race_time").\
withColumnRenamed("race_id","race_id_res").\
withColumnRenamed("file_date","result_file_date")
display(results_df)

# COMMAND ----------

const_df=spark.read.format("delta").load(f'{processed_folder_path}/constructors').withColumnRenamed("name","team")
display(const_df)

# COMMAND ----------

drivers_df=spark.read.format("delta").load(f'{processed_folder_path}/drivers').withColumnRenamed("name","driver_name").\
withColumnRenamed("number","driver_number").\
withColumnRenamed("nationality","driver_nationality")
display(drivers_df)

# COMMAND ----------

circuits_df=spark.read.format("delta").load(f'{processed_folder_path}/circuits').withColumnRenamed("location","circuits_location")
display(circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Inner join on Results,races,driver,constructors

# COMMAND ----------

trans_df=results_df.join(races_df,races_df.race_id==results_df.race_id_res,"inner")\
.join(circuits_df,circuits_df.circuit_id==races_df.circuit_id,"inner")\
.join(const_df,results_df.constructor_id==const_df.constructor_id,"inner")\
.join(drivers_df,results_df.driver_id==drivers_df.driver_id,"inner")\
.select(results_df.race_id_res,races_df.race_year,races_df.race_name,races_df.race_date,
       circuits_df.circuits_location,drivers_df.driver_name,
       drivers_df.driver_number,drivers_df.driver_nationality,const_df.team,results_df.position,
      results_df.grid,results_df.fastest_lap,results_df.race_time,results_df.points,results_df.result_file_date).\
withColumn("created_date", current_timestamp()).\
withColumnRenamed("result_file_date","file_date")

# COMMAND ----------

display(trans_df)

# COMMAND ----------

display(trans_df)

# COMMAND ----------

##trans_df.write.mode("overwrite").format("parquet").saveAsTable('presentation.race_results')

# COMMAND ----------

##incremental_load(trans_df,'race_id_res','presentation','race_results')

# COMMAND ----------

##display(spark.read.parquet('/mnt/formula1adlss/presentation/race_results'))

# COMMAND ----------

merge_condition="tgt.driver_name=src.driver_name and tgt.race_id_res=src.race_id_res"
merge_delta_data(trans_df,'presentation','race_results',presentation_folder_path,merge_condition,'race_id_res')

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct file_date from presentation.race_results

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

