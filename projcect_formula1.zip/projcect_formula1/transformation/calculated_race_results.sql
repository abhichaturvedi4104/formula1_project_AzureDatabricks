-- Databricks notebook source
USE processed

-- COMMAND ----------

select * from results limit 1;



-- COMMAND ----------

select * from races limit 1;


-- COMMAND ----------

select * from drivers limit 1;


-- COMMAND ----------

select * from constructors limit 1;

-- COMMAND ----------

CREATE TABLE presentation.calculated_race_result
USING parquet
AS
SELECT race_year,con.name as team,dr.name as driver_name,points,position,11-position as calculated_points
FROM results res
INNER JOIN races rac ON res.race_id=rac.race_id
INNER JOIN constructors con ON con.constructor_id=res.constructor_id
INNER JOIN drivers dr ON dr.driver_id=res.driver_id
WHERE position<=10


-- COMMAND ----------

select * from presentation.calculated_race_result

-- COMMAND ----------

