-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS presentation
LOCATION '/mnt/formula1adlss/presentation/'

-- COMMAND ----------

DESCRIBE DATABASE presentation

-- COMMAND ----------

