-- Databricks notebook source
USE processed

-- COMMAND ----------

DROP DATABASE IF EXISTS processed CASCADE

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS processed
LOCATION "/mnt/formula1adlss/processed/"

-- COMMAND ----------

USE presentation

-- COMMAND ----------

DROP DATABASE IF EXISTS presentation CASCADE

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS presentation
LOCATION "/mnt/formula1adlss/presentation/"

-- COMMAND ----------

